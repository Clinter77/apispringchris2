package com.apispringchris2.apispringchris2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apispringchris2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apispringchris2Application.class, args);
	}

}
