package com.apispringchris2.apispringchris2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apispringchris2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
